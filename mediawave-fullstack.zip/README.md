# 🌊 MediaWave — Full-Stack Video & Audio Platform

A production-ready full-stack media sharing platform built with modern technologies.
Upload, share, and discover videos and audio with real-time features.

---

## 🏗️ Tech Stack

### Backend
| Layer | Technology |
|-------|-----------|
| Runtime | Node.js 20 + TypeScript |
| Framework | Express.js |
| Database | PostgreSQL + Prisma ORM |
| Auth | JWT (access + refresh tokens) + bcryptjs |
| File Storage | Cloudinary (video/audio/images) |
| Queue | Bull + Redis (background video processing) |
| Real-time | Socket.io (WebSockets) |
| Validation | Zod |
| Security | Helmet, CORS, Rate Limiting |
| Logging | Winston |

### Frontend
| Layer | Technology |
|-------|-----------|
| Framework | Next.js 14 (App Router) |
| Language | TypeScript |
| State | Zustand + React Query (TanStack) |
| Styling | TailwindCSS |
| Animations | Framer Motion |
| File Upload | React Dropzone |
| Real-time | Socket.io-client |
| Forms | React Hook Form + Zod |
| Toasts | React Hot Toast |

---

## 📁 Project Structure

```
mediawave/
├── backend/
│   ├── src/
│   │   ├── config/           # DB, Cloudinary, Redis/Bull
│   │   ├── controllers/      # auth, media, comment, user
│   │   ├── middleware/       # auth JWT, error handler
│   │   ├── routes/           # Express routers
│   │   ├── services/         # Socket.io, Bull worker
│   │   ├── utils/            # JWT helpers, Logger
│   │   ├── validators/       # Zod schemas
│   │   └── index.ts          # Entry point
│   ├── prisma/
│   │   └── schema.prisma     # DB models
│   └── Dockerfile
│
├── frontend/
│   ├── src/
│   │   ├── app/
│   │   │   ├── (auth)/       # Login, Register pages
│   │   │   └── (main)/       # Home, Upload, Media, Profile, Explore
│   │   ├── components/       # Navbar, MediaCard, SkeletonCard
│   │   ├── hooks/            # useSocket
│   │   ├── lib/              # Axios API client
│   │   ├── store/            # Zustand auth store
│   │   └── app/globals.css   # Custom animations
│   └── Dockerfile
│
└── docker-compose.yml
```

---

## 🚀 Quick Start (Local Development)

### Prerequisites
- Node.js 20+
- PostgreSQL 15+
- Redis 7+
- Cloudinary account (free tier works)

---

### Step 1 — Clone & Setup

```bash
git clone <your-repo>
cd mediawave
```

---

### Step 2 — Backend Setup

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env`:

```env
PORT=5000
NODE_ENV=development

# Your PostgreSQL connection string
DATABASE_URL=postgresql://postgres:password@localhost:5432/mediawave_db

# Generate strong secrets (at least 32 chars each):
JWT_SECRET=your_super_secret_key_minimum_32_characters_long
JWT_REFRESH_SECRET=another_super_secret_key_min_32_chars

# Cloudinary — get from cloudinary.com dashboard
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret

# Redis
REDIS_URL=redis://localhost:6379

FRONTEND_URL=http://localhost:3000
```

Run DB migrations:

```bash
npx prisma migrate dev --name init
npx prisma generate
```

Start backend:

```bash
npm run dev
```

Start the queue worker (new terminal):

```bash
npx ts-node src/services/queue.worker.ts
```

---

### Step 3 — Frontend Setup

```bash
cd frontend
npm install
cp .env.example .env.local
```

Edit `.env.local`:

```env
NEXT_PUBLIC_API_URL=http://localhost:5000/api
NEXT_PUBLIC_SOCKET_URL=http://localhost:5000
```

Start frontend:

```bash
npm run dev
```

Open **http://localhost:3000** 🎉

---

## 🐳 Docker (Recommended for Production)

```bash
# Copy and fill environment files
cp backend/.env.example backend/.env
# Edit backend/.env with your Cloudinary credentials and JWT secrets

# Build and start all services
docker-compose up --build -d

# Run migrations inside backend container
docker exec mediawave_backend npx prisma migrate deploy

# View logs
docker-compose logs -f backend
```

Services will be available at:
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000
- Redis: localhost:6379
- PostgreSQL: localhost:5432

---

## 📡 API Endpoints

### Auth
```
POST   /api/auth/register      — Create account
POST   /api/auth/login         — Login (returns JWT tokens)
POST   /api/auth/refresh       — Refresh access token
POST   /api/auth/logout        — Logout (requires auth)
GET    /api/auth/me            — Get current user (requires auth)
```

### Media
```
GET    /api/media              — List media (public, supports ?type=VIDEO|AUDIO&search=&tags=)
GET    /api/media/:id          — Get single media + increment views
POST   /api/media/upload/video — Upload video (requires auth, multipart)
POST   /api/media/upload/audio — Upload audio (requires auth, multipart)
DELETE /api/media/:id          — Delete media (owner only)
POST   /api/media/:id/like     — Toggle like (requires auth)
```

### Comments
```
GET    /api/comments/:mediaId  — Get comments with pagination
POST   /api/comments/:mediaId  — Add comment (requires auth)
DELETE /api/comments/:commentId — Delete comment (owner only)
```

### Users
```
GET    /api/users/:username    — Get user profile
PUT    /api/users/me/profile   — Update profile (requires auth)
PUT    /api/users/me/avatar    — Update avatar (requires auth, multipart)
POST   /api/users/:userId/follow — Toggle follow (requires auth)
```

---

## 🔌 Socket.io Events

### Client → Server
```
media:join        { mediaId }       — Join media room for real-time updates
media:leave       { mediaId }       — Leave media room
upload:progress   { mediaId, progress, stage }
comment:typing    { mediaId, username }
comment:stop-typing { mediaId }
```

### Server → Client
```
upload:complete   { mediaId, status }         — Upload done
upload:progress   { mediaId, progress, stage } — Processing progress
comment:new       { comment, mediaId }         — New comment posted
comment:deleted   { commentId, mediaId }       — Comment removed
media:liked       { mediaId, likeCount, isLiked } — Like toggled
```

---

## 🗄️ Database Schema

```
User          — id, email, username, password, avatar, bio, refreshToken
  ↳ Media     — id, title, description, type(VIDEO|AUDIO), url, thumbnailUrl,
                 publicId, duration, size, tags[], status, views, userId
  ↳ Like      — id, userId, mediaId  [unique constraint]
  ↳ Comment   — id, content, userId, mediaId, parentId (for replies)
  ↳ Follow    — id, followerId, followingId [unique constraint]
```

---

## 🎨 Animations (Framer Motion)

| Animation | Location | Description |
|-----------|----------|-------------|
| Page slide-in | All pages | `initial={{ opacity:0, y:20 }}` fade+slide |
| Navbar | Navbar.tsx | Slides down from top on load |
| Stagger grid | Home/Explore | Cards appear one by one with delay |
| Card hover | MediaCard | `whileHover={{ y:-4 }}` lift effect |
| Like bounce | MediaCard | CSS keyframe on heart icon |
| Nav indicator | Navbar | `layoutId` spring transition |
| Modal scale | Profile/Modals | `scale: 0.9 → 1` with backdrop blur |
| Upload progress | Upload page | Animated gradient progress bar |
| Skeleton shimmer | SkeletonCard | CSS gradient animation |
| Audio bars | Player | Staggered wave animation |
| Tag toggle | Explore | `layout` spring for smooth reflow |

---

## 🔐 Security Features

- **Helmet** — Sets secure HTTP headers
- **CORS** — Restricted to frontend origin
- **Rate Limiting** — 100 requests per 15 minutes per IP
- **JWT** — Short-lived access tokens (15min) + refresh tokens (7 days)
- **bcryptjs** — Password hashing with salt rounds 12
- **Zod** — Request body validation on all endpoints
- **Input sanitization** — Prevents XSS via Zod string constraints
- **Owner checks** — Users can only delete their own content

---

## ⚙️ Environment Variables Reference

### Backend `.env`
```env
PORT                    Server port (default: 5000)
NODE_ENV                development | production
DATABASE_URL            PostgreSQL connection string
JWT_SECRET              Access token secret (min 32 chars)
JWT_REFRESH_SECRET      Refresh token secret (min 32 chars)
JWT_EXPIRES_IN          Access token TTL (default: 15m)
JWT_REFRESH_EXPIRES_IN  Refresh token TTL (default: 7d)
CLOUDINARY_CLOUD_NAME   From cloudinary.com dashboard
CLOUDINARY_API_KEY      From cloudinary.com dashboard
CLOUDINARY_API_SECRET   From cloudinary.com dashboard
REDIS_URL               Redis connection string
FRONTEND_URL            For CORS (default: http://localhost:3000)
RATE_LIMIT_WINDOW_MS    Rate limit window in ms (default: 900000)
RATE_LIMIT_MAX          Max requests per window (default: 100)
```

### Frontend `.env.local`
```env
NEXT_PUBLIC_API_URL     Backend API URL
NEXT_PUBLIC_SOCKET_URL  Backend Socket.io URL
```

---

## 📦 File Size Limits

| Type | Max Size | Formats |
|------|----------|---------|
| Video | 500 MB | mp4, mov, avi, webm, mkv |
| Audio | 50 MB | mp3, wav, ogg, aac, flac, m4a |
| Avatar | 5 MB | jpg, jpeg, png, webp |

---

## 🔄 Background Processing (Bull Queue)

Videos go through a processing pipeline after upload:

1. **Upload** → Cloudinary (status: `PROCESSING`)
2. **Queue job** → Bull adds `process-video` job to Redis
3. **Worker** → Fetches video metadata from Cloudinary
4. **Thumbnail** → Auto-generated at 5s mark
5. **Update** → Media record updated with `thumbnailUrl`, `duration`, `size`, status: `READY`
6. **Socket emit** → User notified in real-time

---

## 🌐 Production Deployment

For cloud deployment (e.g., Railway, Render, AWS):

1. Set all environment variables in your platform's dashboard
2. Use a managed PostgreSQL (e.g., Supabase, Railway Postgres, AWS RDS)
3. Use a managed Redis (e.g., Upstash, Railway Redis)
4. Cloudinary handles file storage — no S3 needed
5. Run `npx prisma migrate deploy` on first deployment
6. Start the queue worker as a separate process/dyno

---

## 🛠️ Useful Commands

```bash
# Backend
npm run dev              # Start dev server with hot reload
npm run build            # Compile TypeScript
npx prisma studio        # Visual DB browser (localhost:5555)
npx prisma migrate dev   # Create and apply new migration
npx prisma db seed       # Seed database (if seed file exists)

# Frontend
npm run dev              # Start Next.js dev server
npm run build            # Production build
npm run lint             # ESLint check

# Docker
docker-compose up -d     # Start all services
docker-compose down      # Stop all services
docker-compose logs -f   # Follow all logs
docker exec mediawave_backend npx prisma migrate deploy
```

---

Built with ❤️ — MediaWave Stack: Node.js · PostgreSQL · Redis · Cloudinary · Next.js · Framer Motion
