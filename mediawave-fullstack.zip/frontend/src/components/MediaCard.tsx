// src/components/MediaCard.tsx
'use client';
import { useState, useCallback } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, Play, Music, Eye, MoreVertical, Trash2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { mediaAPI } from '@/lib/api';
import { useAuthStore } from '@/store/auth.store';
import toast from 'react-hot-toast';

interface Media {
  id: string;
  title: string;
  description?: string;
  type: 'VIDEO' | 'AUDIO';
  url: string;
  thumbnailUrl?: string;
  duration?: number;
  views: number;
  tags: string[];
  createdAt: string;
  isLiked?: boolean;
  user: { id: string; username: string; avatar?: string };
  _count: { likes: number; comments: number };
}

interface MediaCardProps {
  media: Media;
  onDelete?: (id: string) => void;
}

const formatDuration = (seconds?: number) => {
  if (!seconds) return '';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
};

export default function MediaCard({ media, onDelete }: MediaCardProps) {
  const [isLiked, setIsLiked] = useState(media.isLiked || false);
  const [likeCount, setLikeCount] = useState(media._count.likes);
  const [likeAnimating, setLikeAnimating] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const { user } = useAuthStore();

  const handleLike = useCallback(async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) { toast.error('Login to like'); return; }

    setIsLiked(!isLiked);
    setLikeCount(isLiked ? likeCount - 1 : likeCount + 1);
    setLikeAnimating(true);
    setTimeout(() => setLikeAnimating(false), 400);

    try {
      await mediaAPI.toggleLike(media.id);
    } catch {
      // Revert on error
      setIsLiked(isLiked);
      setLikeCount(media._count.likes);
    }
  }, [isLiked, likeCount, media.id, user]);

  const handleDelete = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!confirm('Delete this media?')) return;
    try {
      await mediaAPI.deleteMedia(media.id);
      onDelete?.(media.id);
      toast.success('Media deleted');
    } catch {
      toast.error('Failed to delete');
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="group relative"
    >
      <Link href={`/media/${media.id}`}>
        <div className="bg-surface-800 rounded-2xl overflow-hidden border border-white/5 hover:border-brand-500/30 transition-all duration-300">
          {/* Thumbnail / Cover */}
          <div className="relative aspect-video bg-surface-700 overflow-hidden">
            {media.thumbnailUrl ? (
              <img
                src={media.thumbnailUrl}
                alt={media.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-surface-700 to-surface-800">
                {media.type === 'VIDEO' ? (
                  <Play className="w-12 h-12 text-white/20" />
                ) : (
                  <Music className="w-12 h-12 text-white/20" />
                )}
              </div>
            )}

            {/* Play overlay */}
            <motion.div
              className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200"
              initial={false}
            >
              <motion.div
                className="w-14 h-14 rounded-full bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <Play className="w-6 h-6 text-white fill-white ml-1" />
              </motion.div>
            </motion.div>

            {/* Type badge */}
            <div className={`absolute top-3 left-3 px-2 py-0.5 rounded-md text-[10px] font-bold tracking-wider ${
              media.type === 'VIDEO'
                ? 'bg-brand-500/90 text-white'
                : 'bg-purple-500/90 text-white'
            }`}>
              {media.type}
            </div>

            {/* Duration */}
            {media.duration && (
              <div className="absolute bottom-3 right-3 px-2 py-0.5 rounded-md text-xs font-mono bg-black/70 text-white">
                {formatDuration(media.duration)}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="p-4">
            <div className="flex items-start justify-between gap-2">
              <h3 className="font-semibold text-white/90 line-clamp-2 text-sm leading-snug flex-1">
                {media.title}
              </h3>

              {user?.id === media.user.id && (
                <div className="relative">
                  <motion.button
                    onClick={(e) => { e.preventDefault(); setShowMenu(!showMenu); }}
                    className="p-1 rounded-md text-white/30 hover:text-white/70 hover:bg-white/10 transition-colors"
                    whileTap={{ scale: 0.9 }}
                  >
                    <MoreVertical className="w-4 h-4" />
                  </motion.button>
                  {showMenu && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9, y: -5 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      className="absolute right-0 top-8 glass rounded-xl border border-white/10 shadow-xl z-10 overflow-hidden"
                    >
                      <button
                        onClick={handleDelete}
                        className="flex items-center gap-2 px-4 py-2.5 text-sm text-red-400 hover:bg-red-400/10 w-full text-left transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                        Delete
                      </button>
                    </motion.div>
                  )}
                </div>
              )}
            </div>

            {/* Author */}
            <div className="flex items-center gap-2 mt-2">
              {media.user.avatar ? (
                <img
                  src={media.user.avatar}
                  alt={media.user.username}
                  className="w-5 h-5 rounded-full object-cover"
                />
              ) : (
                <div className="w-5 h-5 rounded-full bg-brand-500/20 flex items-center justify-center">
                  <span className="text-[8px] text-brand-400 font-bold">
                    {media.user.username[0].toUpperCase()}
                  </span>
                </div>
              )}
              <span className="text-xs text-white/40">{media.user.username}</span>
              <span className="text-white/20">·</span>
              <span className="text-xs text-white/30">
                {formatDistanceToNow(new Date(media.createdAt), { addSuffix: true })}
              </span>
            </div>

            {/* Stats */}
            <div className="flex items-center gap-4 mt-3">
              <motion.button
                onClick={handleLike}
                className={`flex items-center gap-1.5 text-xs transition-colors ${
                  isLiked ? 'text-red-400' : 'text-white/40 hover:text-red-400'
                }`}
                whileTap={{ scale: 0.9 }}
              >
                <Heart
                  className={`w-3.5 h-3.5 transition-all ${
                    isLiked ? 'fill-red-400' : ''
                  } ${likeAnimating ? 'like-bounce' : ''}`}
                />
                <span>{likeCount}</span>
              </motion.button>

              <div className="flex items-center gap-1.5 text-xs text-white/40">
                <MessageCircle className="w-3.5 h-3.5" />
                <span>{media._count.comments}</span>
              </div>

              <div className="flex items-center gap-1.5 text-xs text-white/40">
                <Eye className="w-3.5 h-3.5" />
                <span>{media.views}</span>
              </div>
            </div>

            {/* Tags */}
            {media.tags.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-3">
                {media.tags.slice(0, 3).map((tag) => (
                  <span
                    key={tag}
                    className="px-2 py-0.5 text-[10px] rounded-full bg-brand-500/10 text-brand-400 border border-brand-500/20"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
