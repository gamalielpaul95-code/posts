// src/components/Navbar.tsx
'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Upload, Home, Compass, User, LogOut, Waves } from 'lucide-react';
import { useAuthStore } from '@/store/auth.store';
import toast from 'react-hot-toast';

const navItems = [
  { href: '/', icon: Home, label: 'Home' },
  { href: '/explore', icon: Compass, label: 'Explore' },
  { href: '/upload', icon: Upload, label: 'Upload' },
];

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const { user, logout, isAuthenticated } = useAuthStore();

  const handleLogout = async () => {
    await logout();
    toast.success('Logged out');
    router.push('/login');
  };

  return (
    <motion.nav
      className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5"
      initial={{ y: -80 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <motion.div
              className="w-8 h-8 rounded-lg bg-brand-500 flex items-center justify-center glow-brand-sm"
              whileHover={{ scale: 1.1, rotate: 5 }}
              transition={{ type: 'spring', stiffness: 400 }}
            >
              <Waves className="w-4 h-4 text-white" />
            </motion.div>
            <span className="text-lg font-bold tracking-tight">
              Media<span className="text-brand-400">Wave</span>
            </span>
          </Link>

          {/* Nav links */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map(({ href, icon: Icon, label }) => {
              const isActive = pathname === href;
              return (
                <Link key={href} href={href}>
                  <motion.div
                    className={`relative flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      isActive
                        ? 'text-brand-400'
                        : 'text-white/50 hover:text-white/90'
                    }`}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {isActive && (
                      <motion.div
                        layoutId="nav-indicator"
                        className="absolute inset-0 bg-brand-500/10 border border-brand-500/20 rounded-lg"
                        transition={{ type: 'spring', bounce: 0.2, duration: 0.5 }}
                      />
                    )}
                    <Icon className="w-4 h-4 relative z-10" />
                    <span className="relative z-10">{label}</span>
                  </motion.div>
                </Link>
              );
            })}
          </div>

          {/* Auth section */}
          <div className="flex items-center gap-3">
            {isAuthenticated && user ? (
              <>
                <Link href={`/profile/${user.username}`}>
                  <motion.div
                    className="flex items-center gap-2 px-3 py-1.5 rounded-lg glass hover:bg-white/5 cursor-pointer"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {user.avatar ? (
                      <img
                        src={user.avatar}
                        alt={user.username}
                        className="w-7 h-7 rounded-full object-cover ring-2 ring-brand-500/30"
                      />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-brand-500/20 flex items-center justify-center">
                        <User className="w-4 h-4 text-brand-400" />
                      </div>
                    )}
                    <span className="text-sm font-medium hidden sm:block">{user.username}</span>
                  </motion.div>
                </Link>
                <motion.button
                  onClick={handleLogout}
                  className="p-2 rounded-lg text-white/40 hover:text-red-400 hover:bg-red-400/10 transition-colors"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </motion.button>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <Link href="/login">
                  <motion.button
                    className="px-4 py-2 text-sm font-medium text-white/70 hover:text-white transition-colors"
                    whileHover={{ scale: 1.02 }}
                  >
                    Login
                  </motion.button>
                </Link>
                <Link href="/register">
                  <motion.button
                    className="px-4 py-2 text-sm font-medium bg-brand-500 hover:bg-brand-600 rounded-lg transition-colors glow-brand-sm"
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                  >
                    Sign Up
                  </motion.button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile bottom nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 glass border-t border-white/5 px-4 py-2 flex justify-around">
        {navItems.map(({ href, icon: Icon, label }) => {
          const isActive = pathname === href;
          return (
            <Link key={href} href={href}>
              <motion.div
                className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-colors ${
                  isActive ? 'text-brand-400' : 'text-white/40'
                }`}
                whileTap={{ scale: 0.9 }}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-medium">{label}</span>
              </motion.div>
            </Link>
          );
        })}
        {isAuthenticated && user && (
          <Link href={`/profile/${user.username}`}>
            <motion.div
              className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-colors ${
                pathname.startsWith('/profile') ? 'text-brand-400' : 'text-white/40'
              }`}
              whileTap={{ scale: 0.9 }}
            >
              <User className="w-5 h-5" />
              <span className="text-[10px] font-medium">Profile</span>
            </motion.div>
          </Link>
        )}
      </div>
    </motion.nav>
  );
}
