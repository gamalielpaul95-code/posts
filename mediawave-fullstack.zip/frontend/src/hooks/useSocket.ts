// src/hooks/useSocket.ts
'use client';
import { useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { useAuthStore } from '@/store/auth.store';

let socketInstance: Socket | null = null;

export const useSocket = () => {
  const socketRef = useRef<Socket | null>(null);
  const { accessToken } = useAuthStore();

  useEffect(() => {
    if (!socketInstance) {
      socketInstance = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:5000', {
        auth: { token: accessToken || '' },
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 1000,
      });
    }
    socketRef.current = socketInstance;

    return () => {
      // Don't disconnect on component unmount - keep singleton
    };
  }, [accessToken]);

  return socketRef.current;
};

export const getSocket = (): Socket | null => socketInstance;

export const joinMediaRoom = (mediaId: string) => {
  socketInstance?.emit('media:join', mediaId);
};

export const leaveMediaRoom = (mediaId: string) => {
  socketInstance?.emit('media:leave', mediaId);
};
