// src/lib/api.ts
import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

// Request interceptor - attach access token
api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = localStorage.getItem('accessToken');
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor - handle token refresh
api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const refreshToken = localStorage.getItem('refreshToken');
        if (!refreshToken) throw new Error('No refresh token');

        const { data } = await axios.post(
          `${process.env.NEXT_PUBLIC_API_URL}/auth/refresh`,
          { refreshToken }
        );

        const { accessToken, refreshToken: newRefresh } = data.data;
        localStorage.setItem('accessToken', accessToken);
        localStorage.setItem('refreshToken', newRefresh);

        originalRequest.headers!.Authorization = `Bearer ${accessToken}`;
        return api(originalRequest);
      } catch {
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        window.location.href = '/login';
        return Promise.reject(error);
      }
    }

    return Promise.reject(error);
  }
);

// API methods
export const authAPI = {
  register: (data: { email: string; username: string; password: string }) =>
    api.post('/auth/register', data),
  login: (data: { email: string; password: string }) =>
    api.post('/auth/login', data),
  logout: () => api.post('/auth/logout'),
  getMe: () => api.get('/auth/me'),
};

export const mediaAPI = {
  getMedia: (params?: Record<string, any>) => api.get('/media', { params }),
  getMediaById: (id: string) => api.get(`/media/${id}`),
  uploadVideo: (formData: FormData, onProgress?: (pct: number) => void) =>
    api.post('/media/upload/video', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (e) => {
        if (onProgress && e.total) {
          onProgress(Math.round((e.loaded * 100) / e.total));
        }
      },
    }),
  uploadAudio: (formData: FormData, onProgress?: (pct: number) => void) =>
    api.post('/media/upload/audio', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (e) => {
        if (onProgress && e.total) {
          onProgress(Math.round((e.loaded * 100) / e.total));
        }
      },
    }),
  deleteMedia: (id: string) => api.delete(`/media/${id}`),
  toggleLike: (id: string) => api.post(`/media/${id}/like`),
};

export const commentAPI = {
  getComments: (mediaId: string, params?: Record<string, any>) =>
    api.get(`/comments/${mediaId}`, { params }),
  addComment: (mediaId: string, data: { content: string; parentId?: string }) =>
    api.post(`/comments/${mediaId}`, data),
  deleteComment: (commentId: string) => api.delete(`/comments/${commentId}`),
};

export const userAPI = {
  getProfile: (username: string) => api.get(`/users/${username}`),
  updateProfile: (data: { username?: string; bio?: string }) =>
    api.put('/users/me/profile', data),
  updateAvatar: (formData: FormData) =>
    api.put('/users/me/avatar', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),
  toggleFollow: (userId: string) => api.post(`/users/${userId}/follow`),
};

export default api;
