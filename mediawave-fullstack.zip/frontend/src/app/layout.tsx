// src/app/layout.tsx
import type { Metadata } from 'next';
import { Toaster } from 'react-hot-toast';
import Providers from '@/components/Providers';
import './globals.css';

export const metadata: Metadata = {
  title: 'MediaWave — Share Your World',
  description: 'Upload, share, and discover videos and audio with MediaWave',
  manifest: '/manifest.json',
  themeColor: '#0ea5e9',
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="sw" className="dark">
      <body className="bg-surface-900 text-white antialiased font-sans">
        <Providers>
          {children}
          <Toaster
            position="top-right"
            toastOptions={{
              style: {
                background: '#161f32',
                color: '#fff',
                border: '1px solid rgba(56, 189, 248, 0.2)',
                borderRadius: '12px',
              },
              success: { iconTheme: { primary: '#0ea5e9', secondary: '#fff' } },
            }}
          />
        </Providers>
      </body>
    </html>
  );
}
