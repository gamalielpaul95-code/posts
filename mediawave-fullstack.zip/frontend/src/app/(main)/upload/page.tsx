// src/app/(main)/upload/page.tsx
'use client';
import { useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { useDropzone } from 'react-dropzone';
import { Upload, Video, Music, X, Tag, FileVideo, FileAudio, CheckCircle, AlertCircle } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { mediaAPI } from '@/lib/api';
import { useAuthStore } from '@/store/auth.store';
import Navbar from '@/components/Navbar';
import toast from 'react-hot-toast';

const schema = z.object({
  title: z.string().min(1, 'Title is required').max(200),
  description: z.string().max(2000).optional(),
  tags: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

type UploadStage = 'idle' | 'uploading' | 'processing' | 'done' | 'error';

export default function UploadPage() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const [file, setFile] = useState<File | null>(null);
  const [fileType, setFileType] = useState<'VIDEO' | 'AUDIO' | null>(null);
  const [progress, setProgress] = useState(0);
  const [stage, setStage] = useState<UploadStage>('idle');
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const f = acceptedFiles[0];
    if (!f) return;

    const isVideo = f.type.startsWith('video/');
    const isAudio = f.type.startsWith('audio/');

    if (!isVideo && !isAudio) {
      toast.error('Please upload a video or audio file');
      return;
    }

    setFile(f);
    setFileType(isVideo ? 'VIDEO' : 'AUDIO');
    setPreviewUrl(URL.createObjectURL(f));
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'video/*': ['.mp4', '.mov', '.avi', '.webm', '.mkv'],
      'audio/*': ['.mp3', '.wav', '.ogg', '.aac', '.flac', '.m4a'],
    },
    multiple: false,
    maxSize: 500 * 1024 * 1024,
  });

  const removeFile = () => {
    setFile(null);
    setFileType(null);
    setPreviewUrl(null);
    setProgress(0);
    setStage('idle');
  };

  const onSubmit = async (data: FormData) => {
    if (!file || !fileType || !isAuthenticated) {
      toast.error('Please login and select a file');
      return;
    }

    setStage('uploading');
    setProgress(0);

    const formData = new FormData();
    formData.append('file', file);
    formData.append('title', data.title);
    if (data.description) formData.append('description', data.description);
    if (data.tags) formData.append('tags', data.tags);

    try {
      const uploadFn = fileType === 'VIDEO' ? mediaAPI.uploadVideo : mediaAPI.uploadAudio;
      const response = await uploadFn(formData, (pct) => {
        setProgress(pct);
        if (pct === 100) setStage('processing');
      });

      setStage('done');
      toast.success('Upload successful!');
      setTimeout(() => router.push(`/media/${response.data.data.id}`), 1500);
    } catch (err: any) {
      setStage('error');
      toast.error(err?.response?.data?.message || 'Upload failed');
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes > 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024 / 1024).toFixed(1)} GB`;
    if (bytes > 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
    return `${(bytes / 1024).toFixed(0)} KB`;
  };

  return (
    <div className="min-h-screen bg-surface-900">
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 pt-24 pb-16">
        {/* Header */}
        <motion.div
          className="text-center mb-10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-3xl font-bold mb-2">Upload Media</h1>
          <p className="text-white/40">Share your video au audio na world</p>
        </motion.div>

        <motion.form
          onSubmit={handleSubmit(onSubmit)}
          className="space-y-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          {/* Drop zone */}
          <div>
            {!file ? (
              <div
                {...getRootProps()}
                className={`relative border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all duration-300 upload-zone
                  ${isDragActive
                    ? 'border-brand-500 bg-brand-500/5 glow-brand'
                    : 'border-white/10 hover:border-brand-500/40 hover:bg-brand-500/5'
                  }`}
              >
                <input {...getInputProps()} />
                <motion.div
                  animate={{ y: isDragActive ? -8 : 0 }}
                  transition={{ type: 'spring', stiffness: 300 }}
                >
                  <div className="w-16 h-16 rounded-2xl bg-surface-700 flex items-center justify-center mx-auto mb-4">
                    <Upload className="w-8 h-8 text-brand-400" />
                  </div>
                  <p className="text-lg font-medium text-white/80 mb-1">
                    {isDragActive ? 'Acha hapa!' : 'Drag & drop au click kutafuta'}
                  </p>
                  <p className="text-sm text-white/30">
                    Video: MP4, MOV, AVI, WebM (max 500MB) · Audio: MP3, WAV, OGG, AAC (max 50MB)
                  </p>
                </motion.div>
              </div>
            ) : (
              <motion.div
                className="bg-surface-800 rounded-2xl border border-white/10 overflow-hidden"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
              >
                {/* Preview */}
                {fileType === 'VIDEO' && previewUrl && (
                  <video
                    src={previewUrl}
                    className="w-full max-h-56 object-cover"
                    muted
                    preload="metadata"
                  />
                )}

                {fileType === 'AUDIO' && previewUrl && (
                  <div className="p-6 flex items-center justify-center bg-gradient-to-br from-purple-900/20 to-surface-800">
                    <div className="flex items-center gap-2">
                      {[...Array(12)].map((_, i) => (
                        <div
                          key={i}
                          className="audio-bar"
                          style={{ animationDelay: `${i * 0.1}s`, height: `${Math.random() * 20 + 10}px` }}
                        />
                      ))}
                    </div>
                  </div>
                )}

                <div className="p-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-surface-700 flex items-center justify-center shrink-0">
                    {fileType === 'VIDEO' ? (
                      <FileVideo className="w-5 h-5 text-brand-400" />
                    ) : (
                      <FileAudio className="w-5 h-5 text-purple-400" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white/90 truncate">{file.name}</p>
                    <p className="text-xs text-white/30">{formatSize(file.size)}</p>
                  </div>
                  <motion.button
                    type="button"
                    onClick={removeFile}
                    className="p-2 rounded-lg text-white/40 hover:text-red-400 hover:bg-red-400/10 transition-colors"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    disabled={stage === 'uploading' || stage === 'processing'}
                  >
                    <X className="w-4 h-4" />
                  </motion.button>
                </div>

                {/* Progress */}
                <AnimatePresence>
                  {(stage === 'uploading' || stage === 'processing') && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="px-4 pb-4"
                    >
                      <div className="flex justify-between text-xs text-white/50 mb-2">
                        <span>
                          {stage === 'uploading' ? `Inapakia... ${progress}%` : '⚡ Inasindika...'}
                        </span>
                        {stage === 'uploading' && <span>{progress}%</span>}
                      </div>
                      <div className="w-full bg-surface-700 rounded-full h-2 overflow-hidden">
                        <motion.div
                          className="h-full bg-gradient-to-r from-brand-500 to-cyan-400 rounded-full progress-glow"
                          initial={{ width: 0 }}
                          animate={{ width: stage === 'processing' ? '100%' : `${progress}%` }}
                          transition={{ duration: 0.3, ease: 'easeOut' }}
                        />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}
          </div>

          {/* Form fields */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-white/70 mb-1.5">
                Title <span className="text-red-400">*</span>
              </label>
              <input
                {...register('title')}
                placeholder="Weka jina la media yako..."
                className="w-full bg-surface-800 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-brand-500/50 transition-colors"
              />
              {errors.title && (
                <p className="text-red-400 text-xs mt-1">{errors.title.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-white/70 mb-1.5">
                Description
              </label>
              <textarea
                {...register('description')}
                placeholder="Elezea media yako..."
                rows={3}
                className="w-full bg-surface-800 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-brand-500/50 transition-colors resize-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-white/70 mb-1.5">
                <div className="flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5" />
                  Tags (comma separated)
                </div>
              </label>
              <input
                {...register('tags')}
                placeholder="muziki, dance, comedy..."
                className="w-full bg-surface-800 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-brand-500/50 transition-colors"
              />
            </div>
          </div>

          {/* Submit button */}
          <motion.button
            type="submit"
            disabled={!file || stage === 'uploading' || stage === 'processing' || stage === 'done'}
            className={`w-full py-4 rounded-xl font-semibold text-sm transition-all flex items-center justify-center gap-2 ${
              stage === 'done'
                ? 'bg-green-500 text-white'
                : stage === 'error'
                ? 'bg-red-500/20 border border-red-500/30 text-red-400'
                : !file
                ? 'bg-surface-700 text-white/30 cursor-not-allowed'
                : 'bg-brand-500 hover:bg-brand-600 text-white glow-brand-sm'
            }`}
            whileHover={file && stage === 'idle' ? { scale: 1.01 } : {}}
            whileTap={file && stage === 'idle' ? { scale: 0.99 } : {}}
          >
            {stage === 'idle' && (
              <>
                <Upload className="w-4 h-4" />
                Upload Media
              </>
            )}
            {stage === 'uploading' && (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Inapakia {progress}%...
              </>
            )}
            {stage === 'processing' && (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Inasindika...
              </>
            )}
            {stage === 'done' && (
              <>
                <CheckCircle className="w-4 h-4" />
                Upload Complete!
              </>
            )}
            {stage === 'error' && (
              <>
                <AlertCircle className="w-4 h-4" />
                Jaribu tena
              </>
            )}
          </motion.button>
        </motion.form>
      </div>
    </div>
  );
}
