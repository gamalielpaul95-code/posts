// src/app/(main)/media/[id]/page.tsx
'use client';
import { useState, useEffect, useRef } from 'react';
import { useParams } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Heart, MessageCircle, Share2, Trash2, Send,
  Eye, ChevronDown, Play, Music
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { mediaAPI, commentAPI, userAPI } from '@/lib/api';
import { useAuthStore } from '@/store/auth.store';
import { joinMediaRoom, leaveMediaRoom } from '@/hooks/useSocket';
import { io } from 'socket.io-client';
import Navbar from '@/components/Navbar';
import toast from 'react-hot-toast';

export default function MediaPage() {
  const { id } = useParams<{ id: string }>();
  const { user, isAuthenticated } = useAuthStore();
  const queryClient = useQueryClient();
  const commentInputRef = useRef<HTMLTextAreaElement>(null);

  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [likeAnimating, setLikeAnimating] = useState(false);
  const [comment, setComment] = useState('');
  const [isFollowing, setIsFollowing] = useState(false);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);

  // Fetch media
  const { data: mediaData, isLoading } = useQuery({
    queryKey: ['media', id],
    queryFn: () => mediaAPI.getMediaById(id).then((r) => r.data.data),
    enabled: !!id,
  });

  // Fetch comments
  const { data: commentsData, refetch: refetchComments } = useQuery({
    queryKey: ['comments', id],
    queryFn: () => commentAPI.getComments(id).then((r) => r.data.data),
    enabled: !!id,
  });

  useEffect(() => {
    if (mediaData) {
      setIsLiked(mediaData.isLiked || false);
      setLikeCount(mediaData._count?.likes || 0);
      setIsFollowing(mediaData.user?.isFollowing || false);
    }
  }, [mediaData]);

  // Socket.io real-time
  useEffect(() => {
    if (!id) return;

    const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:5000', {
      auth: { token: localStorage.getItem('accessToken') || '' },
    });

    socket.on('connect', () => joinMediaRoom(id));
    socket.on('comment:new', () => refetchComments());
    socket.on('comment:deleted', () => refetchComments());
    socket.on('media:liked', (data: { likeCount: number }) => {
      setLikeCount(data.likeCount);
    });
    socket.on('comment:typing', (data: { username: string }) => {
      setTypingUsers((prev) => [...new Set([...prev, data.username])]);
    });
    socket.on('comment:stop-typing', () => {
      setTypingUsers([]);
    });

    return () => {
      leaveMediaRoom(id);
      socket.disconnect();
    };
  }, [id]);

  const handleLike = async () => {
    if (!isAuthenticated) { toast.error('Login kwanza'); return; }
    setIsLiked(!isLiked);
    setLikeCount(isLiked ? likeCount - 1 : likeCount + 1);
    setLikeAnimating(true);
    setTimeout(() => setLikeAnimating(false), 400);
    try {
      await mediaAPI.toggleLike(id);
    } catch {
      setIsLiked(isLiked);
    }
  };

  const handleComment = async () => {
    if (!comment.trim()) return;
    if (!isAuthenticated) { toast.error('Login kwanza'); return; }
    try {
      await commentAPI.addComment(id, { content: comment.trim() });
      setComment('');
      refetchComments();
    } catch {
      toast.error('Failed to post comment');
    }
  };

  const handleFollow = async () => {
    if (!mediaData || !isAuthenticated) return;
    setIsFollowing(!isFollowing);
    try {
      await userAPI.toggleFollow(mediaData.user.id);
    } catch {
      setIsFollowing(isFollowing);
    }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('Link copied!');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-surface-900">
        <Navbar />
        <div className="max-w-5xl mx-auto px-4 pt-24">
          <div className="skeleton aspect-video w-full rounded-2xl mb-6" />
          <div className="skeleton h-8 w-2/3 rounded mb-3" />
          <div className="skeleton h-4 w-1/3 rounded" />
        </div>
      </div>
    );
  }

  if (!mediaData) {
    return (
      <div className="min-h-screen bg-surface-900 flex items-center justify-center">
        <p className="text-white/40">Media haikupatikana</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface-900">
      <Navbar />
      <div className="max-w-5xl mx-auto px-4 pt-20 pb-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Player */}
          <div className="rounded-2xl overflow-hidden bg-black mb-6 shadow-2xl">
            {mediaData.type === 'VIDEO' ? (
              <video
                src={mediaData.url}
                controls
                className="w-full max-h-[560px]"
                poster={mediaData.thumbnailUrl}
              />
            ) : (
              <div className="p-8 bg-gradient-to-br from-purple-900/30 to-surface-800">
                <div className="flex flex-col items-center gap-6">
                  <div className="w-24 h-24 rounded-2xl bg-purple-500/20 flex items-center justify-center">
                    <Music className="w-12 h-12 text-purple-300" />
                  </div>
                  <div className="flex items-center gap-2">
                    {[...Array(20)].map((_, i) => (
                      <div
                        key={i}
                        className="audio-bar"
                        style={{
                          animationDelay: `${i * 0.06}s`,
                          height: `${Math.random() * 30 + 10}px`,
                        }}
                      />
                    ))}
                  </div>
                  <audio src={mediaData.url} controls className="w-full max-w-md" />
                </div>
              </div>
            )}
          </div>

          {/* Title & Info */}
          <div className="flex flex-col md:flex-row md:items-start gap-4 mb-6">
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-white mb-2">{mediaData.title}</h1>
              <div className="flex items-center gap-3 text-sm text-white/40">
                <span className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  {mediaData.views} views
                </span>
                <span>·</span>
                <span>{formatDistanceToNow(new Date(mediaData.createdAt), { addSuffix: true })}</span>
              </div>
              {mediaData.tags?.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {mediaData.tags.map((tag: string) => (
                    <span
                      key={tag}
                      className="px-3 py-1 text-xs rounded-full bg-brand-500/10 text-brand-400 border border-brand-500/20"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-2">
              <motion.button
                onClick={handleLike}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  isLiked
                    ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                    : 'bg-surface-800 text-white/60 border border-white/10 hover:border-red-500/30'
                }`}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
              >
                <Heart
                  className={`w-4 h-4 transition-all ${isLiked ? 'fill-red-400' : ''} ${
                    likeAnimating ? 'like-bounce' : ''
                  }`}
                />
                <span>{likeCount}</span>
              </motion.button>

              <motion.button
                onClick={handleShare}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium bg-surface-800 text-white/60 border border-white/10 hover:border-brand-500/30 transition-all"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
              >
                <Share2 className="w-4 h-4" />
                Share
              </motion.button>
            </div>
          </div>

          {/* Author card */}
          <div className="glass rounded-2xl p-4 flex items-center gap-4 mb-8">
            {mediaData.user?.avatar ? (
              <img
                src={mediaData.user.avatar}
                alt={mediaData.user.username}
                className="w-12 h-12 rounded-full object-cover ring-2 ring-brand-500/30"
              />
            ) : (
              <div className="w-12 h-12 rounded-full bg-brand-500/20 flex items-center justify-center shrink-0">
                <span className="text-brand-400 font-bold text-lg">
                  {mediaData.user?.username?.[0]?.toUpperCase()}
                </span>
              </div>
            )}
            <div className="flex-1">
              <p className="font-semibold text-white">{mediaData.user?.username}</p>
              <p className="text-xs text-white/40">
                {mediaData.user?._count?.followers || 0} followers · {mediaData.user?._count?.media || 0} posts
              </p>
            </div>
            {user?.id !== mediaData.user?.id && isAuthenticated && (
              <motion.button
                onClick={handleFollow}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                  isFollowing
                    ? 'bg-surface-700 text-white/60 border border-white/10'
                    : 'bg-brand-500 text-white glow-brand-sm hover:bg-brand-600'
                }`}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
              >
                {isFollowing ? 'Following' : 'Follow'}
              </motion.button>
            )}
          </div>

          {/* Description */}
          {mediaData.description && (
            <div className="bg-surface-800 rounded-xl p-4 mb-8 text-sm text-white/60 leading-relaxed">
              {mediaData.description}
            </div>
          )}

          {/* Comments section */}
          <div>
            <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-brand-400" />
              Comments
              <span className="text-white/30 font-normal text-sm">
                ({commentsData?.total || 0})
              </span>
            </h2>

            {/* Comment input */}
            {isAuthenticated && (
              <motion.div
                className="flex gap-3 mb-6"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                <div className="w-8 h-8 rounded-full bg-brand-500/20 flex items-center justify-center shrink-0 mt-1">
                  <span className="text-brand-400 font-bold text-xs">
                    {user?.username?.[0]?.toUpperCase()}
                  </span>
                </div>
                <div className="flex-1">
                  <textarea
                    ref={commentInputRef}
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleComment();
                      }
                    }}
                    placeholder="Andika comment yako..."
                    rows={2}
                    className="w-full bg-surface-800 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-brand-500/50 transition-colors resize-none"
                  />
                  <div className="flex justify-end mt-2">
                    <motion.button
                      onClick={handleComment}
                      disabled={!comment.trim()}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg bg-brand-500 text-white text-sm font-medium disabled:opacity-40 disabled:cursor-not-allowed hover:bg-brand-600 transition-colors"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Send className="w-4 h-4" />
                      Post
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Typing indicator */}
            <AnimatePresence>
              {typingUsers.length > 0 && (
                <motion.p
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="text-xs text-white/30 mb-3"
                >
                  {typingUsers.join(', ')} {typingUsers.length === 1 ? 'is' : 'are'} typing...
                </motion.p>
              )}
            </AnimatePresence>

            {/* Comments list */}
            <AnimatePresence>
              {commentsData?.comments?.map((c: any) => (
                <CommentItem key={c.id} comment={c} currentUserId={user?.id} onDeleted={refetchComments} />
              ))}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function CommentItem({ comment, currentUserId, onDeleted }: any) {
  const handleDelete = async () => {
    try {
      await commentAPI.deleteComment(comment.id);
      onDeleted();
    } catch {
      toast.error('Failed to delete');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -10 }}
      className="flex gap-3 py-4 border-b border-white/5 group"
    >
      <div className="w-8 h-8 rounded-full bg-surface-700 flex items-center justify-center shrink-0">
        {comment.user?.avatar ? (
          <img src={comment.user.avatar} className="w-8 h-8 rounded-full object-cover" alt="" />
        ) : (
          <span className="text-xs text-white/50 font-bold">
            {comment.user?.username?.[0]?.toUpperCase()}
          </span>
        )}
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sm font-medium text-white/80">{comment.user?.username}</span>
          <span className="text-xs text-white/30">
            {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
          </span>
        </div>
        <p className="text-sm text-white/60 leading-relaxed">{comment.content}</p>
      </div>
      {currentUserId === comment.userId && (
        <motion.button
          onClick={handleDelete}
          className="opacity-0 group-hover:opacity-100 p-1.5 rounded-lg text-white/30 hover:text-red-400 hover:bg-red-400/10 transition-all"
          whileTap={{ scale: 0.9 }}
        >
          <Trash2 className="w-3.5 h-3.5" />
        </motion.button>
      )}
    </motion.div>
  );
}
