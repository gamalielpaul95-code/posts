// src/app/(main)/explore/page.tsx
'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { Search, TrendingUp, Hash, X } from 'lucide-react';
import { mediaAPI } from '@/lib/api';
import MediaCard from '@/components/MediaCard';
import SkeletonCard from '@/components/SkeletonCard';
import Navbar from '@/components/Navbar';

const POPULAR_TAGS = [
  'muziki', 'comedy', 'dance', 'news', 'sports', 'tech',
  'education', 'cooking', 'travel', 'gaming', 'art', 'fashion',
];

export default function ExplorePage() {
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  const handleSearchChange = (val: string) => {
    setSearch(val);
    clearTimeout((window as any).__searchTimer);
    (window as any).__searchTimer = setTimeout(() => setDebouncedSearch(val), 400);
  };

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const { data, isLoading } = useQuery({
    queryKey: ['explore', debouncedSearch, selectedTags],
    queryFn: () =>
      mediaAPI.getMedia({
        search: debouncedSearch || undefined,
        tags: selectedTags.length ? selectedTags.join(',') : undefined,
        limit: 24,
      }).then((r) => r.data.data),
  });

  return (
    <div className="min-h-screen bg-surface-900">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 pt-24 pb-24">
        {/* Header */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-brand-500/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-brand-400" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Explore</h1>
              <p className="text-white/40 text-sm">Gundua media mpya na ya kuvutia</p>
            </div>
          </div>

          {/* Search */}
          <div className="relative max-w-xl mb-5">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <input
              value={search}
              onChange={(e) => handleSearchChange(e.target.value)}
              placeholder="Tafuta media, mada, wabunifu..."
              className="w-full bg-surface-800 border border-white/10 rounded-xl pl-11 pr-4 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-brand-500/50 transition-colors"
            />
            {search && (
              <button
                onClick={() => { setSearch(''); setDebouncedSearch(''); }}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Tags */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Hash className="w-4 h-4 text-white/30" />
              <span className="text-sm text-white/40">Chagua mada</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {POPULAR_TAGS.map((tag) => {
                const active = selectedTags.includes(tag);
                return (
                  <motion.button
                    key={tag}
                    onClick={() => toggleTag(tag)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${
                      active
                        ? 'bg-brand-500/20 text-brand-400 border-brand-500/40'
                        : 'bg-surface-800 text-white/40 border-white/10 hover:text-white/70 hover:border-white/20'
                    }`}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    layout
                  >
                    #{tag}
                    {active && (
                      <motion.span
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="ml-1"
                      >
                        ×
                      </motion.span>
                    )}
                  </motion.button>
                );
              })}
            </div>

            {selectedTags.length > 0 && (
              <motion.button
                onClick={() => setSelectedTags([])}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="mt-2 text-xs text-white/30 hover:text-white/60 transition-colors flex items-center gap-1"
              >
                <X className="w-3 h-3" />
                Clear all filters
              </motion.button>
            )}
          </div>
        </motion.div>

        {/* Results count */}
        {!isLoading && data?.media && (
          <motion.p
            className="text-sm text-white/30 mb-5"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {data.pagination?.total || data.media.length} matokeo yamepatikana
          </motion.p>
        )}

        {/* Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {[...Array(12)].map((_, i) => <SkeletonCard key={i} />)}
          </div>
        ) : (
          <AnimatePresence mode="wait">
            {data?.media?.length === 0 ? (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-24"
              >
                <div className="w-16 h-16 rounded-2xl bg-surface-800 flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-white/20" />
                </div>
                <p className="text-white/30 text-lg">Hakuna matokeo</p>
                <p className="text-white/20 text-sm mt-1">Jaribu maneno tofauti au futa filters</p>
              </motion.div>
            ) : (
              <motion.div
                key="results"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5"
              >
                {data?.media?.map((media: any, i: number) => (
                  <motion.div
                    key={media.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.04 }}
                  >
                    <MediaCard media={media} />
                  </motion.div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}
