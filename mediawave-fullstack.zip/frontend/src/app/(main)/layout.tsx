// src/app/(main)/layout.tsx
'use client';
import { useEffect } from 'react';
import { useAuthStore } from '@/store/auth.store';

export default function MainLayout({ children }: { children: React.ReactNode }) {
  const { hydrate } = useAuthStore();

  useEffect(() => {
    hydrate();
  }, []);

  return <>{children}</>;
}
