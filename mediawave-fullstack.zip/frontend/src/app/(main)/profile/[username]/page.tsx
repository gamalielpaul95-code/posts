// src/app/(main)/profile/[username]/page.tsx
'use client';
import { useState } from 'react';
import { useParams } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { Grid, Music, Video, Users, Heart, Edit2, Camera } from 'lucide-react';
import { userAPI, mediaAPI } from '@/lib/api';
import { useAuthStore } from '@/store/auth.store';
import MediaCard from '@/components/MediaCard';
import SkeletonCard from '@/components/SkeletonCard';
import Navbar from '@/components/Navbar';
import toast from 'react-hot-toast';

export default function ProfilePage() {
  const { username } = useParams<{ username: string }>();
  const { user: currentUser, isAuthenticated } = useAuthStore();
  const [isFollowing, setIsFollowing] = useState(false);
  const [mediaType, setMediaType] = useState<'ALL' | 'VIDEO' | 'AUDIO'>('ALL');
  const [showEditModal, setShowEditModal] = useState(false);

  const { data: profileData, isLoading: profileLoading } = useQuery({
    queryKey: ['profile', username],
    queryFn: () => userAPI.getProfile(username).then((r) => {
      setIsFollowing(r.data.data.isFollowing);
      return r.data.data;
    }),
    enabled: !!username,
  });

  const { data: mediaData, isLoading: mediaLoading, refetch: refetchMedia } = useQuery({
    queryKey: ['user-media', username, mediaType],
    queryFn: () =>
      mediaAPI.getMedia({
        userId: profileData?.id,
        type: mediaType === 'ALL' ? undefined : mediaType,
        limit: 20,
      }).then((r) => r.data.data),
    enabled: !!profileData?.id,
  });

  const handleFollow = async () => {
    if (!isAuthenticated) { toast.error('Login kwanza'); return; }
    setIsFollowing(!isFollowing);
    try {
      await userAPI.toggleFollow(profileData.id);
    } catch {
      setIsFollowing(isFollowing);
    }
  };

  const isOwner = currentUser?.username === username;

  if (profileLoading) {
    return (
      <div className="min-h-screen bg-surface-900">
        <Navbar />
        <div className="max-w-5xl mx-auto px-4 pt-24">
          <div className="flex flex-col items-center gap-4 mb-10">
            <div className="skeleton w-24 h-24 rounded-full" />
            <div className="skeleton h-6 w-40 rounded" />
            <div className="skeleton h-4 w-64 rounded" />
          </div>
        </div>
      </div>
    );
  }

  if (!profileData) {
    return (
      <div className="min-h-screen bg-surface-900 flex items-center justify-center">
        <p className="text-white/40">Mtumiaji hakupatikana</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface-900">
      <Navbar />

      {/* Hero gradient */}
      <div className="relative pt-16">
        <div className="h-48 bg-gradient-to-br from-brand-900/40 via-surface-800 to-purple-900/20 relative overflow-hidden">
          <div className="absolute inset-0 noise" />
          <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-surface-900 to-transparent" />
        </div>

        <div className="max-w-5xl mx-auto px-4">
          {/* Profile info */}
          <div className="relative -mt-16 flex flex-col sm:flex-row items-start sm:items-end gap-4 mb-8">
            {/* Avatar */}
            <div className="relative group">
              {profileData.avatar ? (
                <img
                  src={profileData.avatar}
                  alt={profileData.username}
                  className="w-24 h-24 rounded-2xl object-cover ring-4 ring-surface-900 border-2 border-brand-500/30"
                />
              ) : (
                <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-brand-500/30 to-purple-500/30 flex items-center justify-center ring-4 ring-surface-900 border-2 border-brand-500/30">
                  <span className="text-3xl font-bold text-brand-300">
                    {profileData.username[0].toUpperCase()}
                  </span>
                </div>
              )}
              {isOwner && (
                <motion.button
                  className="absolute inset-0 rounded-2xl bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  whileTap={{ scale: 0.95 }}
                  title="Change avatar"
                >
                  <Camera className="w-5 h-5 text-white" />
                </motion.button>
              )}
            </div>

            <div className="flex-1">
              <h1 className="text-2xl font-bold text-white">{profileData.username}</h1>
              {profileData.bio && (
                <p className="text-white/50 text-sm mt-1 max-w-md">{profileData.bio}</p>
              )}
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-2 sm:pb-2">
              {isOwner ? (
                <motion.button
                  onClick={() => setShowEditModal(true)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium bg-surface-800 border border-white/10 text-white/70 hover:border-brand-500/30 hover:text-white transition-all"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.97 }}
                >
                  <Edit2 className="w-4 h-4" />
                  Edit Profile
                </motion.button>
              ) : (
                <motion.button
                  onClick={handleFollow}
                  className={`px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    isFollowing
                      ? 'bg-surface-700 text-white/60 border border-white/10'
                      : 'bg-brand-500 text-white glow-brand-sm hover:bg-brand-600'
                  }`}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                >
                  {isFollowing ? 'Following' : 'Follow'}
                </motion.button>
              )}
            </div>
          </div>

          {/* Stats */}
          <motion.div
            className="grid grid-cols-3 gap-4 mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            {[
              { icon: Grid, label: 'Posts', value: profileData._count?.media || 0 },
              { icon: Users, label: 'Followers', value: profileData._count?.followers || 0 },
              { icon: Heart, label: 'Following', value: profileData._count?.following || 0 },
            ].map(({ icon: Icon, label, value }) => (
              <div key={label} className="glass rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-white">{value}</div>
                <div className="text-xs text-white/40 mt-1 flex items-center justify-center gap-1">
                  <Icon className="w-3 h-3" />
                  {label}
                </div>
              </div>
            ))}
          </motion.div>

          {/* Media type filter */}
          <div className="flex gap-2 mb-6">
            {(['ALL', 'VIDEO', 'AUDIO'] as const).map((t) => (
              <motion.button
                key={t}
                onClick={() => setMediaType(t)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                  mediaType === t
                    ? 'bg-brand-500 text-white'
                    : 'bg-surface-800 text-white/50 hover:text-white border border-white/10'
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
              >
                {t === 'VIDEO' && <Video className="w-3.5 h-3.5" />}
                {t === 'AUDIO' && <Music className="w-3.5 h-3.5" />}
                {t === 'ALL' && <Grid className="w-3.5 h-3.5" />}
                {t}
              </motion.button>
            ))}
          </div>

          {/* Media grid */}
          {mediaLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {[...Array(6)].map((_, i) => <SkeletonCard key={i} />)}
            </div>
          ) : (
            <AnimatePresence mode="wait">
              {mediaData?.media?.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-20"
                >
                  <div className="w-16 h-16 rounded-2xl bg-surface-800 flex items-center justify-center mx-auto mb-4">
                    <Grid className="w-8 h-8 text-white/20" />
                  </div>
                  <p className="text-white/30">
                    {isOwner ? 'Bado hujapakia media yoyote' : 'Hakuna media ya mtumiaji huyu'}
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  key={mediaType}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 pb-24"
                >
                  {mediaData?.media?.map((media: any) => (
                    <MediaCard
                      key={media.id}
                      media={media}
                      onDelete={() => refetchMedia()}
                    />
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          )}
        </div>
      </div>

      {/* Edit Profile Modal */}
      <AnimatePresence>
        {showEditModal && (
          <EditProfileModal
            user={profileData}
            onClose={() => setShowEditModal(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function EditProfileModal({ user, onClose }: { user: any; onClose: () => void }) {
  const [bio, setBio] = useState(user.bio || '');
  const [username, setUsername] = useState(user.username || '');
  const [saving, setSaving] = useState(false);
  const { setUser } = useAuthStore();

  const handleSave = async () => {
    setSaving(true);
    try {
      const { data } = await userAPI.updateProfile({ username, bio });
      setUser(data.data);
      toast.success('Profile updated!');
      onClose();
    } catch (err: any) {
      toast.error(err?.response?.data?.message || 'Update failed');
    } finally {
      setSaving(false);
    }
  };

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      <motion.div
        className="relative glass rounded-2xl p-6 w-full max-w-md border border-white/10"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ type: 'spring', bounce: 0.2 }}
      >
        <h2 className="text-lg font-bold mb-5">Edit Profile</h2>

        <div className="space-y-4">
          <div>
            <label className="block text-sm text-white/60 mb-1.5">Username</label>
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-surface-800 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-500/50 transition-colors"
            />
          </div>
          <div>
            <label className="block text-sm text-white/60 mb-1.5">Bio</label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={3}
              placeholder="Jiambie kidogo..."
              className="w-full bg-surface-800 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-brand-500/50 resize-none transition-colors"
            />
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button
            onClick={onClose}
            className="flex-1 py-3 rounded-xl text-sm font-medium bg-surface-700 text-white/60 hover:text-white transition-colors"
          >
            Cancel
          </button>
          <motion.button
            onClick={handleSave}
            disabled={saving}
            className="flex-1 py-3 rounded-xl text-sm font-medium bg-brand-500 text-white disabled:opacity-60 hover:bg-brand-600 transition-colors flex items-center justify-center gap-2"
            whileTap={{ scale: 0.98 }}
          >
            {saving ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : 'Save Changes'}
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  );
}
