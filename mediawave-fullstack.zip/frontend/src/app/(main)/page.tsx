// src/app/(main)/page.tsx
'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { Search, Sliders, Video, Music } from 'lucide-react';
import { mediaAPI } from '@/lib/api';
import MediaCard from '@/components/MediaCard';
import SkeletonCard from '@/components/SkeletonCard';
import Navbar from '@/components/Navbar';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.07 },
  },
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
};

export default function HomePage() {
  const [search, setSearch] = useState('');
  const [type, setType] = useState<'ALL' | 'VIDEO' | 'AUDIO'>('ALL');
  const [debouncedSearch, setDebouncedSearch] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['media', type, debouncedSearch],
    queryFn: () =>
      mediaAPI.getMedia({
        type: type === 'ALL' ? undefined : type,
        search: debouncedSearch || undefined,
      }).then((r) => r.data.data),
  });

  const handleSearch = (val: string) => {
    setSearch(val);
    const timer = setTimeout(() => setDebouncedSearch(val), 400);
    return () => clearTimeout(timer);
  };

  return (
    <div className="min-h-screen bg-surface-900">
      <Navbar />

      {/* Hero gradient */}
      <div className="relative pt-16">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-brand-500/10 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 py-12 md:py-16 relative">
          {/* Headline */}
          <motion.div
            className="text-center mb-10"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
          >
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-3">
              Discover{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 to-cyan-300">
                Amazing Media
              </span>
            </h1>
            <p className="text-white/40 text-lg">Videos na audio kutoka kwa wabunifu duniani kote</p>
          </motion.div>

          {/* Search & Filters */}
          <motion.div
            className="flex flex-col sm:flex-row gap-3 max-w-2xl mx-auto mb-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
              <input
                type="text"
                value={search}
                onChange={(e) => handleSearch(e.target.value)}
                placeholder="Tafuta video au audio..."
                className="w-full bg-surface-800 border border-white/10 rounded-xl pl-11 pr-4 py-3 text-sm text-white placeholder-white/30 focus:outline-none focus:border-brand-500/50 transition-colors"
              />
            </div>

            <div className="flex gap-2">
              {(['ALL', 'VIDEO', 'AUDIO'] as const).map((t) => (
                <motion.button
                  key={t}
                  onClick={() => setType(t)}
                  className={`flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                    type === t
                      ? 'bg-brand-500 text-white glow-brand-sm'
                      : 'bg-surface-800 text-white/50 hover:text-white/80 border border-white/10'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.97 }}
                >
                  {t === 'VIDEO' && <Video className="w-4 h-4" />}
                  {t === 'AUDIO' && <Music className="w-4 h-4" />}
                  {t === 'ALL' && <Sliders className="w-4 h-4" />}
                  <span className="hidden sm:block">{t}</span>
                </motion.button>
              ))}
            </div>
          </motion.div>

          {/* Media Grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {Array.from({ length: 8 }).map((_, i) => (
                <SkeletonCard key={i} />
              ))}
            </div>
          ) : (
            <AnimatePresence mode="wait">
              {data?.media?.length === 0 ? (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-24"
                >
                  <div className="w-16 h-16 rounded-2xl bg-surface-800 flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-white/20" />
                  </div>
                  <p className="text-white/40 text-lg">Hakuna media iliyopatikana</p>
                  <p className="text-white/20 text-sm mt-1">Jaribu kutafuta kwa neno lingine</p>
                </motion.div>
              ) : (
                <motion.div
                  key="grid"
                  variants={container}
                  initial="hidden"
                  animate="show"
                  className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5"
                >
                  {data?.media?.map((media: any) => (
                    <motion.div key={media.id} variants={item}>
                      <MediaCard media={media} />
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          )}
        </div>
      </div>
    </div>
  );
}
