// src/config/queue.ts
import Bull from 'bull';
import IORedis from 'ioredis';
import { logger } from '../utils/logger';

const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379';

// Redis client
export const redisClient = new IORedis(redisUrl, {
  maxRetriesPerRequest: null,
  enableReadyCheck: false,
});

redisClient.on('connect', () => logger.info('✅ Redis connected'));
redisClient.on('error', (err) => logger.error('❌ Redis error:', err));

// Media processing queue
export const mediaQueue = new Bull('media-processing', redisUrl, {
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 2000,
    },
    removeOnComplete: 100,
    removeOnFail: 50,
  },
});

// Notification queue
export const notificationQueue = new Bull('notifications', redisUrl, {
  defaultJobOptions: {
    attempts: 3,
    removeOnComplete: true,
  },
});

logger.info('📋 Bull queues initialized');
