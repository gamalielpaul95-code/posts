// src/config/cloudinary.ts
import { v2 as cloudinary } from 'cloudinary';
import multer from 'multer';
import { CloudinaryStorage } from 'multer-storage-cloudinary';

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure: true,
});

// Cloudinary storage for videos
const videoStorage = new CloudinaryStorage({
  cloudinary,
  params: async (_req, _file) => ({
    folder: 'mediawave/videos',
    resource_type: 'video',
    allowed_formats: ['mp4', 'mov', 'avi', 'webm', 'mkv'],
    transformation: [
      { quality: 'auto', fetch_format: 'auto' },
    ],
  }),
});

// Cloudinary storage for audio
const audioStorage = new CloudinaryStorage({
  cloudinary,
  params: async (_req, _file) => ({
    folder: 'mediawave/audio',
    resource_type: 'video', // Cloudinary uses 'video' for audio too
    allowed_formats: ['mp3', 'wav', 'ogg', 'aac', 'flac', 'm4a'],
  }),
});

// Cloudinary storage for avatars
const avatarStorage = new CloudinaryStorage({
  cloudinary,
  params: async (_req, _file) => ({
    folder: 'mediawave/avatars',
    resource_type: 'image',
    allowed_formats: ['jpg', 'jpeg', 'png', 'webp'],
    transformation: [
      { width: 400, height: 400, crop: 'fill', gravity: 'face' },
      { quality: 'auto', fetch_format: 'auto' },
    ],
  }),
});

// File size limits
const fileLimits = {
  video: { fileSize: 500 * 1024 * 1024 }, // 500MB
  audio: { fileSize: 50 * 1024 * 1024 },  // 50MB
  avatar: { fileSize: 5 * 1024 * 1024 },  // 5MB
};

export const uploadVideo = multer({
  storage: videoStorage,
  limits: fileLimits.video,
  fileFilter: (_req, file, cb) => {
    const allowed = ['video/mp4', 'video/quicktime', 'video/avi', 'video/webm', 'video/x-matroska'];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid video format. Allowed: mp4, mov, avi, webm, mkv'));
    }
  },
});

export const uploadAudio = multer({
  storage: audioStorage,
  limits: fileLimits.audio,
  fileFilter: (_req, file, cb) => {
    const allowed = ['audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/aac', 'audio/flac', 'audio/mp4'];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid audio format. Allowed: mp3, wav, ogg, aac, flac, m4a'));
    }
  },
});

export const uploadAvatar = multer({
  storage: avatarStorage,
  limits: fileLimits.avatar,
});

export { cloudinary };
