// src/config/database.ts
import { PrismaClient } from '@prisma/client';
import { logger } from '../utils/logger';

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma;

// Test connection
prisma.$connect()
  .then(() => logger.info('✅ PostgreSQL connected via Prisma'))
  .catch((err: Error) => logger.error('❌ Database connection failed:', err));

export default prisma;
