// src/controllers/comment.controller.ts
import { Response, NextFunction } from 'express';
import { prisma } from '../config/database';
import { AppError } from '../middleware/error.middleware';
import { AuthRequest } from '../middleware/auth.middleware';
import { commentSchema } from '../validators';
import { io } from '../index';

export const getComments = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { mediaId } = req.params;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const skip = (page - 1) * limit;

    const [comments, total] = await Promise.all([
      prisma.comment.findMany({
        where: { mediaId, parentId: null },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          user: { select: { id: true, username: true, avatar: true } },
          replies: {
            include: {
              user: { select: { id: true, username: true, avatar: true } },
            },
            orderBy: { createdAt: 'asc' },
            take: 3,
          },
          _count: { select: { replies: true } },
        },
      }),
      prisma.comment.count({ where: { mediaId, parentId: null } }),
    ]);

    res.json({
      success: true,
      data: {
        comments,
        pagination: { page, limit, total, pages: Math.ceil(total / limit) },
      },
    });
  } catch (err) {
    next(err);
  }
};

export const addComment = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { mediaId } = req.params;
    const data = commentSchema.parse(req.body);
    const userId = req.user!.userId;

    const media = await prisma.media.findUnique({ where: { id: mediaId } });
    if (!media) throw new AppError('Media not found', 404);

    if (data.parentId) {
      const parent = await prisma.comment.findUnique({ where: { id: data.parentId } });
      if (!parent) throw new AppError('Parent comment not found', 404);
    }

    const comment = await prisma.comment.create({
      data: { content: data.content, userId, mediaId, parentId: data.parentId },
      include: {
        user: { select: { id: true, username: true, avatar: true } },
        replies: {
          include: { user: { select: { id: true, username: true, avatar: true } } },
        },
        _count: { select: { replies: true } },
      },
    });

    // Emit real-time comment to everyone watching this media
    io.to(`media:${mediaId}`).emit('comment:new', { comment, mediaId });

    res.status(201).json({ success: true, data: comment });
  } catch (err) {
    next(err);
  }
};

export const deleteComment = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { commentId } = req.params;
    const userId = req.user!.userId;

    const comment = await prisma.comment.findUnique({ where: { id: commentId } });
    if (!comment) throw new AppError('Comment not found', 404);
    if (comment.userId !== userId) throw new AppError('Unauthorized', 403);

    await prisma.comment.delete({ where: { id: commentId } });

    io.to(`media:${comment.mediaId}`).emit('comment:deleted', { commentId, mediaId: comment.mediaId });

    res.json({ success: true, message: 'Comment deleted' });
  } catch (err) {
    next(err);
  }
};
