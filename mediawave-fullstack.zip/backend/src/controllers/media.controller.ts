// src/controllers/media.controller.ts
import { Response, NextFunction } from 'express';
import { prisma } from '../config/database';
import { cloudinary } from '../config/cloudinary';
import { mediaQueue } from '../config/queue';
import { AppError } from '../middleware/error.middleware';
import { AuthRequest } from '../middleware/auth.middleware';
import { mediaUploadSchema, mediaQuerySchema } from '../validators';
import { io } from '../index';

// Upload video
export const uploadVideo = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.file) throw new AppError('No video file provided', 400);
    const data = mediaUploadSchema.parse(req.body);
    const file = req.file as Express.Multer.File & { path: string; filename: string; public_id?: string };

    // Create media record with PROCESSING status
    const media = await prisma.media.create({
      data: {
        title: data.title,
        description: data.description,
        type: 'VIDEO',
        url: file.path,
        publicId: (file as any).public_id || file.filename,
        tags: data.tags ? data.tags.split(',').map((t) => t.trim()).filter(Boolean) : [],
        status: 'PROCESSING',
        userId: req.user!.userId,
      },
      include: {
        user: { select: { id: true, username: true, avatar: true } },
        _count: { select: { likes: true, comments: true } },
      },
    });

    // Queue background processing (thumbnail generation, transcoding info)
    await mediaQueue.add('process-video', {
      mediaId: media.id,
      publicId: media.publicId,
      userId: req.user!.userId,
    });

    // Emit real-time event to user
    io.to(`user:${req.user!.userId}`).emit('upload:complete', {
      mediaId: media.id,
      status: 'PROCESSING',
    });

    res.status(201).json({
      success: true,
      message: 'Video uploaded successfully, processing in background',
      data: media,
    });
  } catch (err) {
    next(err);
  }
};

// Upload audio
export const uploadAudio = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.file) throw new AppError('No audio file provided', 400);
    const data = mediaUploadSchema.parse(req.body);
    const file = req.file as Express.Multer.File & { path: string; filename: string };

    const media = await prisma.media.create({
      data: {
        title: data.title,
        description: data.description,
        type: 'AUDIO',
        url: file.path,
        publicId: (file as any).public_id || file.filename,
        tags: data.tags ? data.tags.split(',').map((t) => t.trim()).filter(Boolean) : [],
        status: 'READY', // Audio is ready immediately
        userId: req.user!.userId,
      },
      include: {
        user: { select: { id: true, username: true, avatar: true } },
        _count: { select: { likes: true, comments: true } },
      },
    });

    io.to(`user:${req.user!.userId}`).emit('upload:complete', {
      mediaId: media.id,
      status: 'READY',
    });

    res.status(201).json({
      success: true,
      message: 'Audio uploaded successfully',
      data: media,
    });
  } catch (err) {
    next(err);
  }
};

// Get all media (feed)
export const getMedia = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const query = mediaQuerySchema.parse(req.query);
    const page = Number(query.page) || 1;
    const limit = Number(query.limit) || 12;
    const skip = (page - 1) * limit;

    const where: any = { status: 'READY' };

    if (query.type) where.type = query.type;
    if (query.userId) where.userId = query.userId;
    if (query.tags) {
      where.tags = { hasSome: query.tags.split(',').map((t: string) => t.trim()) };
    }
    if (query.search) {
      where.OR = [
        { title: { contains: query.search, mode: 'insensitive' } },
        { description: { contains: query.search, mode: 'insensitive' } },
      ];
    }

    const [media, total] = await Promise.all([
      prisma.media.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          user: { select: { id: true, username: true, avatar: true } },
          _count: { select: { likes: true, comments: true } },
          ...(req.user ? {
            likes: {
              where: { userId: req.user.userId },
              select: { id: true },
            },
          } : {}),
        },
      }),
      prisma.media.count({ where }),
    ]);

    const mediaWithLiked = media.map((m: any) => ({
      ...m,
      isLiked: req.user ? m.likes?.length > 0 : false,
      likes: undefined,
    }));

    res.json({
      success: true,
      data: {
        media: mediaWithLiked,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      },
    });
  } catch (err) {
    next(err);
  }
};

// Get single media
export const getMediaById = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;

    const media = await prisma.media.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            avatar: true,
            bio: true,
            _count: { select: { followers: true, media: true } },
          },
        },
        _count: { select: { likes: true, comments: true } },
        ...(req.user ? {
          likes: {
            where: { userId: req.user.userId },
            select: { id: true },
          },
        } : {}),
      },
    });

    if (!media) throw new AppError('Media not found', 404);

    // Increment views
    await prisma.media.update({
      where: { id },
      data: { views: { increment: 1 } },
    });

    res.json({
      success: true,
      data: {
        ...media,
        isLiked: req.user ? (media as any).likes?.length > 0 : false,
        likes: undefined,
      },
    });
  } catch (err) {
    next(err);
  }
};

// Delete media
export const deleteMedia = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;

    const media = await prisma.media.findUnique({ where: { id } });
    if (!media) throw new AppError('Media not found', 404);
    if (media.userId !== req.user!.userId) throw new AppError('Unauthorized', 403);

    // Delete from Cloudinary
    const resourceType = media.type === 'VIDEO' ? 'video' : 'video';
    await cloudinary.uploader.destroy(media.publicId, { resource_type: resourceType });

    await prisma.media.delete({ where: { id } });

    res.json({ success: true, message: 'Media deleted successfully' });
  } catch (err) {
    next(err);
  }
};

// Toggle like
export const toggleLike = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const userId = req.user!.userId;

    const media = await prisma.media.findUnique({ where: { id } });
    if (!media) throw new AppError('Media not found', 404);

    const existingLike = await prisma.like.findUnique({
      where: { userId_mediaId: { userId, mediaId: id } },
    });

    let isLiked: boolean;

    if (existingLike) {
      await prisma.like.delete({
        where: { userId_mediaId: { userId, mediaId: id } },
      });
      isLiked = false;
    } else {
      await prisma.like.create({ data: { userId, mediaId: id } });
      isLiked = true;
    }

    const likeCount = await prisma.like.count({ where: { mediaId: id } });

    // Emit real-time like event
    io.to(`media:${id}`).emit('media:liked', { mediaId: id, likeCount, isLiked, userId });

    res.json({ success: true, data: { isLiked, likeCount } });
  } catch (err) {
    next(err);
  }
};
