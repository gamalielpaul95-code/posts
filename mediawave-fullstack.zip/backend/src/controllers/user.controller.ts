// src/controllers/user.controller.ts
import { Response, NextFunction } from 'express';
import { prisma } from '../config/database';
import { AppError } from '../middleware/error.middleware';
import { AuthRequest } from '../middleware/auth.middleware';
import { updateProfileSchema } from '../validators';

export const getUserProfile = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { username } = req.params;

    const user = await prisma.user.findUnique({
      where: { username },
      select: {
        id: true,
        username: true,
        avatar: true,
        bio: true,
        createdAt: true,
        _count: {
          select: { media: true, followers: true, following: true },
        },
      },
    });

    if (!user) throw new AppError('User not found', 404);

    let isFollowing = false;
    if (req.user) {
      const follow = await prisma.follow.findUnique({
        where: {
          followerId_followingId: {
            followerId: req.user.userId,
            followingId: user.id,
          },
        },
      });
      isFollowing = !!follow;
    }

    res.json({ success: true, data: { ...user, isFollowing } });
  } catch (err) {
    next(err);
  }
};

export const updateProfile = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const data = updateProfileSchema.parse(req.body);

    if (data.username) {
      const existing = await prisma.user.findFirst({
        where: { username: data.username, NOT: { id: req.user!.userId } },
      });
      if (existing) throw new AppError('Username already taken', 409);
    }

    const user = await prisma.user.update({
      where: { id: req.user!.userId },
      data,
      select: {
        id: true,
        email: true,
        username: true,
        avatar: true,
        bio: true,
        createdAt: true,
      },
    });

    res.json({ success: true, data: user });
  } catch (err) {
    next(err);
  }
};

export const updateAvatar = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.file) throw new AppError('No image provided', 400);
    const file = req.file as Express.Multer.File & { path: string };

    const user = await prisma.user.update({
      where: { id: req.user!.userId },
      data: { avatar: file.path },
      select: { id: true, username: true, avatar: true },
    });

    res.json({ success: true, data: user });
  } catch (err) {
    next(err);
  }
};

export const toggleFollow = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { userId: targetId } = req.params;
    const followerId = req.user!.userId;

    if (followerId === targetId) throw new AppError('Cannot follow yourself', 400);

    const target = await prisma.user.findUnique({ where: { id: targetId } });
    if (!target) throw new AppError('User not found', 404);

    const existing = await prisma.follow.findUnique({
      where: { followerId_followingId: { followerId, followingId: targetId } },
    });

    let isFollowing: boolean;

    if (existing) {
      await prisma.follow.delete({
        where: { followerId_followingId: { followerId, followingId: targetId } },
      });
      isFollowing = false;
    } else {
      await prisma.follow.create({ data: { followerId, followingId: targetId } });
      isFollowing = true;
    }

    const followerCount = await prisma.follow.count({ where: { followingId: targetId } });

    res.json({ success: true, data: { isFollowing, followerCount } });
  } catch (err) {
    next(err);
  }
};
