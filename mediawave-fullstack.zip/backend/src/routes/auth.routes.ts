// src/routes/auth.routes.ts
import { Router } from 'express';
import { register, login, refreshTokens, logout, getMe } from '../controllers/auth.controller';
import { authenticate } from '../middleware/auth.middleware';

export const authRouter = Router();

authRouter.post('/register', register);
authRouter.post('/login', login);
authRouter.post('/refresh', refreshTokens);
authRouter.post('/logout', authenticate, logout);
authRouter.get('/me', authenticate, getMe);
