// src/routes/user.routes.ts
import { Router } from 'express';
import {
  getUserProfile,
  updateProfile,
  updateAvatar,
  toggleFollow,
} from '../controllers/user.controller';
import { authenticate, optionalAuth } from '../middleware/auth.middleware';
import { uploadAvatar } from '../config/cloudinary';

export const userRouter = Router();

userRouter.get('/:username', optionalAuth, getUserProfile);
userRouter.put('/me/profile', authenticate, updateProfile);
userRouter.put('/me/avatar', authenticate, uploadAvatar.single('avatar'), updateAvatar);
userRouter.post('/:userId/follow', authenticate, toggleFollow);
