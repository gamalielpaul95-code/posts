// src/routes/media.routes.ts
import { Router } from 'express';
import {
  uploadVideo,
  uploadAudio,
  getMedia,
  getMediaById,
  deleteMedia,
  toggleLike,
} from '../controllers/media.controller';
import { authenticate, optionalAuth } from '../middleware/auth.middleware';
import { uploadVideo as videoUploader, uploadAudio as audioUploader } from '../config/cloudinary';

export const mediaRouter = Router();

// Public routes
mediaRouter.get('/', optionalAuth, getMedia);
mediaRouter.get('/:id', optionalAuth, getMediaById);

// Protected routes
mediaRouter.post('/upload/video', authenticate, videoUploader.single('file'), uploadVideo);
mediaRouter.post('/upload/audio', authenticate, audioUploader.single('file'), uploadAudio);
mediaRouter.delete('/:id', authenticate, deleteMedia);
mediaRouter.post('/:id/like', authenticate, toggleLike);
