// src/routes/comment.routes.ts
import { Router } from 'express';
import { getComments, addComment, deleteComment } from '../controllers/comment.controller';
import { authenticate } from '../middleware/auth.middleware';

export const commentRouter = Router();

commentRouter.get('/:mediaId', getComments);
commentRouter.post('/:mediaId', authenticate, addComment);
commentRouter.delete('/:commentId', authenticate, deleteComment);
