// src/services/socket.service.ts
import { Server, Socket } from 'socket.io';
import { verifyAccessToken } from '../utils/jwt';
import { logger } from '../utils/logger';

export const setupSocketHandlers = (io: Server): void => {
  // Auth middleware for socket connections
  io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    if (token) {
      try {
        const payload = verifyAccessToken(token);
        (socket as any).userId = payload.userId;
      } catch {
        // Allow unauthenticated connections for viewing
      }
    }
    next();
  });

  io.on('connection', (socket: Socket) => {
    const userId = (socket as any).userId;
    logger.info(`🔌 Socket connected: ${socket.id}${userId ? ` (user: ${userId})` : ''}`);

    // Join user's personal room for notifications
    if (userId) {
      socket.join(`user:${userId}`);
      logger.info(`👤 User ${userId} joined personal room`);
    }

    // Join media room for real-time comments/likes
    socket.on('media:join', (mediaId: string) => {
      socket.join(`media:${mediaId}`);
      logger.info(`📺 Socket ${socket.id} joined media room: ${mediaId}`);
    });

    socket.on('media:leave', (mediaId: string) => {
      socket.leave(`media:${mediaId}`);
    });

    // Upload progress events (emitted from client during chunked upload)
    socket.on('upload:progress', (data: { mediaId: string; progress: number; stage: string }) => {
      if (userId) {
        io.to(`user:${userId}`).emit('upload:progress', data);
      }
    });

    // Typing indicator for comments
    socket.on('comment:typing', (data: { mediaId: string; username: string }) => {
      socket.to(`media:${data.mediaId}`).emit('comment:typing', {
        username: data.username,
        socketId: socket.id,
      });
    });

    socket.on('comment:stop-typing', (data: { mediaId: string }) => {
      socket.to(`media:${data.mediaId}`).emit('comment:stop-typing', {
        socketId: socket.id,
      });
    });

    // Presence tracking
    socket.on('disconnect', () => {
      logger.info(`🔌 Socket disconnected: ${socket.id}`);
    });
  });
};

// Helper to emit upload progress from workers
export const emitUploadProgress = (
  io: Server,
  userId: string,
  data: { mediaId: string; progress: number; stage: string; status?: string }
): void => {
  io.to(`user:${userId}`).emit('upload:progress', data);
};
