// src/services/queue.worker.ts
// Run this as a separate process: ts-node src/services/queue.worker.ts
import dotenv from 'dotenv';
dotenv.config();

import { mediaQueue } from '../config/queue';
import { prisma } from '../config/database';
import { cloudinary } from '../config/cloudinary';
import { logger } from '../utils/logger';

interface VideoJobData {
  mediaId: string;
  publicId: string;
  userId: string;
}

mediaQueue.process('process-video', async (job) => {
  const { mediaId, publicId, userId } = job.data as VideoJobData;
  logger.info(`Processing video job: ${mediaId}`);

  try {
    // Update progress
    await job.progress(10);

    // Get video info from Cloudinary
    const videoInfo = await cloudinary.api.resource(publicId, {
      resource_type: 'video',
      media_metadata: true,
    });

    await job.progress(40);

    // Generate thumbnail from video (Cloudinary auto-generates)
    const thumbnailUrl = cloudinary.url(publicId, {
      resource_type: 'video',
      format: 'jpg',
      transformation: [
        { width: 640, height: 360, crop: 'fill' },
        { quality: 'auto' },
        { start_offset: '5' }, // Thumbnail at 5 seconds
      ],
    });

    await job.progress(70);

    // Update media record
    await prisma.media.update({
      where: { id: mediaId },
      data: {
        status: 'READY',
        thumbnailUrl,
        duration: videoInfo.duration,
        size: videoInfo.bytes,
      },
    });

    await job.progress(100);
    logger.info(`✅ Video processed: ${mediaId}`);

    return { success: true, mediaId };
  } catch (error) {
    logger.error(`❌ Video processing failed: ${mediaId}`, error);

    await prisma.media.update({
      where: { id: mediaId },
      data: { status: 'FAILED' },
    });

    throw error;
  }
});

mediaQueue.on('completed', (job) => {
  logger.info(`Job ${job.id} completed`);
});

mediaQueue.on('failed', (job, err) => {
  logger.error(`Job ${job.id} failed:`, err);
});

logger.info('🔧 Queue worker started, waiting for jobs...');
